<?php
include('header.php');
$this->view($content);
include('footer.php');
?>